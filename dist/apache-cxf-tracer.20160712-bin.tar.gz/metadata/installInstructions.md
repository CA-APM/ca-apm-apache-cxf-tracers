# Apache CXF Tracer (0.0.1)
 
## Description
This fieldpack allows tracing of Apache CXF web services.

# Installation Instructions

## Prerequisites
n/a

## Dependencies
CA APM Java Agent 9.7+

## Installation
Install via APM Command Center as agent bundle or copy pbd to core/config and copy jar to core/ext directories of CA APM Java agent.

## Configuration
n/a

# Usage Instructions
How to use the field pack.

## Metric description
Describe the metrics provided by this field pack or link to third party documentation.

## Custom Management Modules
Dashboards, etc. included with this field pack.

## Custom type viewers
Type viewers included with this field pack. Include agent and metric path that the type viewer matches against.

## Name Formatter Replacements
If the field pack includes name formatters cite all place holders here and what they are replaced with.

## Debugging and Troubleshooting
How to debug and troubleshoot the field pack.
